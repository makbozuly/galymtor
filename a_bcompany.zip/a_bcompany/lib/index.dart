// Export pages
export '/profile/profile/profile_widget.dart' show ProfileWidget;
export '/blok/main/home/home_widget.dart' show HomeWidget;
export '/payment/satyp_alu/satyp_alu_widget.dart' show SatypAluWidget;
export '/profile/suraq_zhauap/suraq_zhauap_widget.dart' show SuraqZhauapWidget;
export '/blok/main/current_glav_news/current_glav_news_widget.dart'
    show CurrentGlavNewsWidget;
export '/blok/main/current_module_lessons/current_module_lessons_widget.dart'
    show CurrentModuleLessonsWidget;
export '/profile/xabarlamalar/xabarlamalar_widget.dart' show XabarlamalarWidget;
export '/profile/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/blok/main/current_lesson/current_lesson_widget.dart'
    show CurrentLessonWidget;
export '/admin/addnews/addnews_widget.dart' show AddnewsWidget;
export '/admin/admin_add_course/admin_add_course_widget.dart'
    show AdminAddCourseWidget;
export '/admin/admin_add_lesson/admin_add_lesson_widget.dart'
    show AdminAddLessonWidget;
export '/admin/addnotif/addnotif_widget.dart' show AddnotifWidget;
export '/admin/addblock/addblock_widget.dart' show AddblockWidget;
export '/admin/admin_lessons/admin_lessons_widget.dart' show AdminLessonsWidget;
export '/admin/admin/admin_widget.dart' show AdminWidget;
export '/payment/auth/authentication/authentication_widget.dart'
    show AuthenticationWidget;
export '/admin/admin_main_panel/admin_main_panel_widget.dart'
    show AdminMainPanelWidget;
export '/admin/addstudent/addstudent_widget.dart' show AddstudentWidget;
export '/admin/add_q_a/add_q_a_widget.dart' show AddQAWidget;
export '/admin/edit_course/edit_course_widget.dart' show EditCourseWidget;
export '/edit_user/edit_user_widget.dart' show EditUserWidget;
export '/payment/auth/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/kaspitutorial/kaspitutorial_widget.dart' show KaspitutorialWidget;
export '/blok/main/module_of_course/module_of_course_widget.dart'
    show ModuleOfCourseWidget;
export '/payment/auth/welcompage/welcompage_widget.dart' show WelcompageWidget;
export '/blok/contents/contents_widget.dart' show ContentsWidget;
export '/blok/currentcontent/currentcontent_widget.dart'
    show CurrentcontentWidget;
export '/users/users_widget.dart' show UsersWidget;
