import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'photo_upload_widget.dart' show PhotoUploadWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class PhotoUploadModel extends FlutterFlowModel<PhotoUploadWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for Namefield widget.
  FocusNode? namefieldFocusNode;
  TextEditingController? namefieldController;
  String? Function(BuildContext, String?)? namefieldControllerValidator;
  // State field(s) for Phonenumberfille widget.
  FocusNode? phonenumberfilleFocusNode;
  TextEditingController? phonenumberfilleController;
  final phonenumberfilleMask =
      MaskTextInputFormatter(mask: '+# (###) ###-##-##');
  String? Function(BuildContext, String?)? phonenumberfilleControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    namefieldFocusNode?.dispose();
    namefieldController?.dispose();

    phonenumberfilleFocusNode?.dispose();
    phonenumberfilleController?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
