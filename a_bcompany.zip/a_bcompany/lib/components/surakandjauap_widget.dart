import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'surakandjauap_model.dart';
export 'surakandjauap_model.dart';

class SurakandjauapWidget extends StatefulWidget {
  const SurakandjauapWidget({
    super.key,
    this.parameter1,
    this.parameter2,
  });

  final String? parameter1;
  final String? parameter2;

  @override
  State<SurakandjauapWidget> createState() => _SurakandjauapWidgetState();
}

class _SurakandjauapWidgetState extends State<SurakandjauapWidget> {
  late SurakandjauapModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SurakandjauapModel());

    _model.expandableController = ExpandableController(initialExpanded: false);
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Container(
      color: Color(0x3363327A),
      child: ExpandableNotifier(
        controller: _model.expandableController,
        child: ExpandablePanel(
          header: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(9.0, 0.0, 0.0, 0.0),
            child: Text(
              widget.parameter1!,
              style: FlutterFlowTheme.of(context).displaySmall.override(
                    fontFamily: 'Montserrat',
                    color: Color(0xE5FFFFFF),
                    fontSize: 18.0,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ),
          collapsed: Container(
            width: MediaQuery.sizeOf(context).width * 1.0,
            height: 1.0,
            decoration: BoxDecoration(
              color: Color(0xBAFFFFFF),
              borderRadius: BorderRadius.circular(10.0),
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
              child: Text(
                FFLocalizations.of(context).getText(
                  '4b2sr7bt' /* Lorem ipsum dolor sit amet, co... */,
                ),
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Montserrat',
                      color: Color(0x8A000000),
                    ),
              ),
            ),
          ),
          expanded: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(9.0, 0.0, 9.0, 9.0),
                child: Text(
                  widget.parameter2!,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Montserrat',
                        color: Color(0xBDFFFFFF),
                      ),
                ),
              ),
            ],
          ),
          theme: ExpandableThemeData(
            tapHeaderToExpand: true,
            tapBodyToExpand: false,
            tapBodyToCollapse: false,
            headerAlignment: ExpandablePanelHeaderAlignment.center,
            hasIcon: true,
            iconSize: 30.0,
            iconColor: Color(0xE5FFFFFF),
          ),
        ),
      ),
    );
  }
}
