import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/success_payment_widget.dart';
import '/components/unsuccess_payment_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/revenue_cat_util.dart' as revenue_cat;
import 'pay_for_vip_widget.dart' show PayForVipWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PayForVipModel extends FlutterFlowModel<PayForVipWidget> {
  ///  State fields for stateful widgets in this component.

  // Stores action output result for [RevenueCat - Purchase] action in Button widget.
  bool? tarif3;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
