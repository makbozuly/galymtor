import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDE3jOG7_dkIrlwVAaKIyWd99rjJ0tii_w",
            authDomain: "ab-company-e19d6.firebaseapp.com",
            projectId: "ab-company-e19d6",
            storageBucket: "ab-company-e19d6.appspot.com",
            messagingSenderId: "397814619433",
            appId: "1:397814619433:web:cd9468219bab617dd1eb38",
            measurementId: "G-8GMCKFF33E"));
  } else {
    await Firebase.initializeApp();
  }
}
