import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SulylyqCodyLessonsRecord extends FirestoreRecord {
  SulylyqCodyLessonsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "lenght" field.
  int? _lenght;
  int get lenght => _lenght ?? 0;
  bool hasLenght() => _lenght != null;

  // "banner" field.
  String? _banner;
  String get banner => _banner ?? '';
  bool hasBanner() => _banner != null;

  // "video" field.
  String? _video;
  String get video => _video ?? '';
  bool hasVideo() => _video != null;

  // "order" field.
  int? _order;
  int get order => _order ?? 0;
  bool hasOrder() => _order != null;

  // "entitlements" field.
  String? _entitlements;
  String get entitlements => _entitlements ?? '';
  bool hasEntitlements() => _entitlements != null;

  // "tarif1" field.
  bool? _tarif1;
  bool get tarif1 => _tarif1 ?? false;
  bool hasTarif1() => _tarif1 != null;

  // "tarif2" field.
  bool? _tarif2;
  bool get tarif2 => _tarif2 ?? false;
  bool hasTarif2() => _tarif2 != null;

  // "tarif3" field.
  bool? _tarif3;
  bool get tarif3 => _tarif3 ?? false;
  bool hasTarif3() => _tarif3 != null;

  // "file" field.
  String? _file;
  String get file => _file ?? '';
  bool hasFile() => _file != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _description = snapshotData['description'] as String?;
    _lenght = castToType<int>(snapshotData['lenght']);
    _banner = snapshotData['banner'] as String?;
    _video = snapshotData['video'] as String?;
    _order = castToType<int>(snapshotData['order']);
    _entitlements = snapshotData['entitlements'] as String?;
    _tarif1 = snapshotData['tarif1'] as bool?;
    _tarif2 = snapshotData['tarif2'] as bool?;
    _tarif3 = snapshotData['tarif3'] as bool?;
    _file = snapshotData['file'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('sulylyq_cody_lessons')
          : FirebaseFirestore.instance.collectionGroup('sulylyq_cody_lessons');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('sulylyq_cody_lessons').doc(id);

  static Stream<SulylyqCodyLessonsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SulylyqCodyLessonsRecord.fromSnapshot(s));

  static Future<SulylyqCodyLessonsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => SulylyqCodyLessonsRecord.fromSnapshot(s));

  static SulylyqCodyLessonsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SulylyqCodyLessonsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SulylyqCodyLessonsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SulylyqCodyLessonsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SulylyqCodyLessonsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SulylyqCodyLessonsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSulylyqCodyLessonsRecordData({
  String? title,
  String? description,
  int? lenght,
  String? banner,
  String? video,
  int? order,
  String? entitlements,
  bool? tarif1,
  bool? tarif2,
  bool? tarif3,
  String? file,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'description': description,
      'lenght': lenght,
      'banner': banner,
      'video': video,
      'order': order,
      'entitlements': entitlements,
      'tarif1': tarif1,
      'tarif2': tarif2,
      'tarif3': tarif3,
      'file': file,
    }.withoutNulls,
  );

  return firestoreData;
}

class SulylyqCodyLessonsRecordDocumentEquality
    implements Equality<SulylyqCodyLessonsRecord> {
  const SulylyqCodyLessonsRecordDocumentEquality();

  @override
  bool equals(SulylyqCodyLessonsRecord? e1, SulylyqCodyLessonsRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.description == e2?.description &&
        e1?.lenght == e2?.lenght &&
        e1?.banner == e2?.banner &&
        e1?.video == e2?.video &&
        e1?.order == e2?.order &&
        e1?.entitlements == e2?.entitlements &&
        e1?.tarif1 == e2?.tarif1 &&
        e1?.tarif2 == e2?.tarif2 &&
        e1?.tarif3 == e2?.tarif3 &&
        e1?.file == e2?.file;
  }

  @override
  int hash(SulylyqCodyLessonsRecord? e) => const ListEquality().hash([
        e?.title,
        e?.description,
        e?.lenght,
        e?.banner,
        e?.video,
        e?.order,
        e?.entitlements,
        e?.tarif1,
        e?.tarif2,
        e?.tarif3,
        e?.file
      ]);

  @override
  bool isValidKey(Object? o) => o is SulylyqCodyLessonsRecord;
}
