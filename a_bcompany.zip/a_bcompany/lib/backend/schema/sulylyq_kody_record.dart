import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SulylyqKodyRecord extends FirestoreRecord {
  SulylyqKodyRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "banner" field.
  String? _banner;
  String get banner => _banner ?? '';
  bool hasBanner() => _banner != null;

  // "subtitle" field.
  String? _subtitle;
  String get subtitle => _subtitle ?? '';
  bool hasSubtitle() => _subtitle != null;

  // "id" field.
  int? _id;
  int get id => _id ?? 0;
  bool hasId() => _id != null;

  // "language" field.
  String? _language;
  String get language => _language ?? '';
  bool hasLanguage() => _language != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _banner = snapshotData['banner'] as String?;
    _subtitle = snapshotData['subtitle'] as String?;
    _id = castToType<int>(snapshotData['id']);
    _language = snapshotData['language'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('sulylyq_kody');

  static Stream<SulylyqKodyRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SulylyqKodyRecord.fromSnapshot(s));

  static Future<SulylyqKodyRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SulylyqKodyRecord.fromSnapshot(s));

  static SulylyqKodyRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SulylyqKodyRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SulylyqKodyRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SulylyqKodyRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SulylyqKodyRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SulylyqKodyRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSulylyqKodyRecordData({
  String? title,
  String? banner,
  String? subtitle,
  int? id,
  String? language,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'banner': banner,
      'subtitle': subtitle,
      'id': id,
      'language': language,
    }.withoutNulls,
  );

  return firestoreData;
}

class SulylyqKodyRecordDocumentEquality implements Equality<SulylyqKodyRecord> {
  const SulylyqKodyRecordDocumentEquality();

  @override
  bool equals(SulylyqKodyRecord? e1, SulylyqKodyRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.banner == e2?.banner &&
        e1?.subtitle == e2?.subtitle &&
        e1?.id == e2?.id &&
        e1?.language == e2?.language;
  }

  @override
  int hash(SulylyqKodyRecord? e) => const ListEquality()
      .hash([e?.title, e?.banner, e?.subtitle, e?.id, e?.language]);

  @override
  bool isValidKey(Object? o) => o is SulylyqKodyRecord;
}
