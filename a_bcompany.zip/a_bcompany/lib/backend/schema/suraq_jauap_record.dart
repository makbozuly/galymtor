import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SuraqJauapRecord extends FirestoreRecord {
  SuraqJauapRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "subtitle" field.
  String? _subtitle;
  String get subtitle => _subtitle ?? '';
  bool hasSubtitle() => _subtitle != null;

  // "order" field.
  int? _order;
  int get order => _order ?? 0;
  bool hasOrder() => _order != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _subtitle = snapshotData['subtitle'] as String?;
    _order = castToType<int>(snapshotData['order']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('suraq_jauap');

  static Stream<SuraqJauapRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SuraqJauapRecord.fromSnapshot(s));

  static Future<SuraqJauapRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SuraqJauapRecord.fromSnapshot(s));

  static SuraqJauapRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SuraqJauapRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SuraqJauapRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SuraqJauapRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SuraqJauapRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SuraqJauapRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSuraqJauapRecordData({
  String? title,
  String? subtitle,
  int? order,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'subtitle': subtitle,
      'order': order,
    }.withoutNulls,
  );

  return firestoreData;
}

class SuraqJauapRecordDocumentEquality implements Equality<SuraqJauapRecord> {
  const SuraqJauapRecordDocumentEquality();

  @override
  bool equals(SuraqJauapRecord? e1, SuraqJauapRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.subtitle == e2?.subtitle &&
        e1?.order == e2?.order;
  }

  @override
  int hash(SuraqJauapRecord? e) =>
      const ListEquality().hash([e?.title, e?.subtitle, e?.order]);

  @override
  bool isValidKey(Object? o) => o is SuraqJauapRecord;
}
