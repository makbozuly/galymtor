import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BlockRecord extends FirestoreRecord {
  BlockRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "banner" field.
  String? _banner;
  String get banner => _banner ?? '';
  bool hasBanner() => _banner != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "Subtitle" field.
  String? _subtitle;
  String get subtitle => _subtitle ?? '';
  bool hasSubtitle() => _subtitle != null;

  // "created_date" field.
  DateTime? _createdDate;
  DateTime? get createdDate => _createdDate;
  bool hasCreatedDate() => _createdDate != null;

  void _initializeFields() {
    _banner = snapshotData['banner'] as String?;
    _title = snapshotData['title'] as String?;
    _subtitle = snapshotData['Subtitle'] as String?;
    _createdDate = snapshotData['created_date'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Block');

  static Stream<BlockRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BlockRecord.fromSnapshot(s));

  static Future<BlockRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BlockRecord.fromSnapshot(s));

  static BlockRecord fromSnapshot(DocumentSnapshot snapshot) => BlockRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BlockRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BlockRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BlockRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BlockRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBlockRecordData({
  String? banner,
  String? title,
  String? subtitle,
  DateTime? createdDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'banner': banner,
      'title': title,
      'Subtitle': subtitle,
      'created_date': createdDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class BlockRecordDocumentEquality implements Equality<BlockRecord> {
  const BlockRecordDocumentEquality();

  @override
  bool equals(BlockRecord? e1, BlockRecord? e2) {
    return e1?.banner == e2?.banner &&
        e1?.title == e2?.title &&
        e1?.subtitle == e2?.subtitle &&
        e1?.createdDate == e2?.createdDate;
  }

  @override
  int hash(BlockRecord? e) => const ListEquality()
      .hash([e?.banner, e?.title, e?.subtitle, e?.createdDate]);

  @override
  bool isValidKey(Object? o) => o is BlockRecord;
}
