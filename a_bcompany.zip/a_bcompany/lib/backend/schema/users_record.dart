import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "howdidknow" field.
  String? _howdidknow;
  String get howdidknow => _howdidknow ?? '';
  bool hasHowdidknow() => _howdidknow != null;

  // "admin" field.
  bool? _admin;
  bool get admin => _admin ?? false;
  bool hasAdmin() => _admin != null;

  // "kirdi" field.
  bool? _kirdi;
  bool get kirdi => _kirdi ?? false;
  bool hasKirdi() => _kirdi != null;

  // "s_cody_tarif1" field.
  bool? _sCodyTarif1;
  bool get sCodyTarif1 => _sCodyTarif1 ?? false;
  bool hasSCodyTarif1() => _sCodyTarif1 != null;

  // "s_cody_tarif1Do" field.
  DateTime? _sCodyTarif1Do;
  DateTime? get sCodyTarif1Do => _sCodyTarif1Do;
  bool hasSCodyTarif1Do() => _sCodyTarif1Do != null;

  // "s_cody_tarif2" field.
  bool? _sCodyTarif2;
  bool get sCodyTarif2 => _sCodyTarif2 ?? false;
  bool hasSCodyTarif2() => _sCodyTarif2 != null;

  // "s_cody_tarif2Do" field.
  DateTime? _sCodyTarif2Do;
  DateTime? get sCodyTarif2Do => _sCodyTarif2Do;
  bool hasSCodyTarif2Do() => _sCodyTarif2Do != null;

  // "s_cody_tarif3" field.
  bool? _sCodyTarif3;
  bool get sCodyTarif3 => _sCodyTarif3 ?? false;
  bool hasSCodyTarif3() => _sCodyTarif3 != null;

  // "s_cody_tarif3Do" field.
  DateTime? _sCodyTarif3Do;
  DateTime? get sCodyTarif3Do => _sCodyTarif3Do;
  bool hasSCodyTarif3Do() => _sCodyTarif3Do != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _howdidknow = snapshotData['howdidknow'] as String?;
    _admin = snapshotData['admin'] as bool?;
    _kirdi = snapshotData['kirdi'] as bool?;
    _sCodyTarif1 = snapshotData['s_cody_tarif1'] as bool?;
    _sCodyTarif1Do = snapshotData['s_cody_tarif1Do'] as DateTime?;
    _sCodyTarif2 = snapshotData['s_cody_tarif2'] as bool?;
    _sCodyTarif2Do = snapshotData['s_cody_tarif2Do'] as DateTime?;
    _sCodyTarif3 = snapshotData['s_cody_tarif3'] as bool?;
    _sCodyTarif3Do = snapshotData['s_cody_tarif3Do'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? howdidknow,
  bool? admin,
  bool? kirdi,
  bool? sCodyTarif1,
  DateTime? sCodyTarif1Do,
  bool? sCodyTarif2,
  DateTime? sCodyTarif2Do,
  bool? sCodyTarif3,
  DateTime? sCodyTarif3Do,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'howdidknow': howdidknow,
      'admin': admin,
      'kirdi': kirdi,
      's_cody_tarif1': sCodyTarif1,
      's_cody_tarif1Do': sCodyTarif1Do,
      's_cody_tarif2': sCodyTarif2,
      's_cody_tarif2Do': sCodyTarif2Do,
      's_cody_tarif3': sCodyTarif3,
      's_cody_tarif3Do': sCodyTarif3Do,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.howdidknow == e2?.howdidknow &&
        e1?.admin == e2?.admin &&
        e1?.kirdi == e2?.kirdi &&
        e1?.sCodyTarif1 == e2?.sCodyTarif1 &&
        e1?.sCodyTarif1Do == e2?.sCodyTarif1Do &&
        e1?.sCodyTarif2 == e2?.sCodyTarif2 &&
        e1?.sCodyTarif2Do == e2?.sCodyTarif2Do &&
        e1?.sCodyTarif3 == e2?.sCodyTarif3 &&
        e1?.sCodyTarif3Do == e2?.sCodyTarif3Do;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.howdidknow,
        e?.admin,
        e?.kirdi,
        e?.sCodyTarif1,
        e?.sCodyTarif1Do,
        e?.sCodyTarif2,
        e?.sCodyTarif2Do,
        e?.sCodyTarif3,
        e?.sCodyTarif3Do
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
