import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/youblocked_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_language_selector.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'authentication_widget.dart' show AuthenticationWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AuthenticationModel extends FlutterFlowModel<AuthenticationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for emailAddress widget.
  FocusNode? emailAddressFocusNode;
  TextEditingController? emailAddressController;
  String? Function(BuildContext, String?)? emailAddressControllerValidator;
  // State field(s) for password widget.
  FocusNode? passwordFocusNode;
  TextEditingController? passwordController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordControllerValidator;
  // State field(s) for confrim widget.
  FocusNode? confrimFocusNode;
  TextEditingController? confrimController;
  late bool confrimVisibility;
  String? Function(BuildContext, String?)? confrimControllerValidator;
  // State field(s) for emailAddress1221 widget.
  FocusNode? emailAddress1221FocusNode;
  TextEditingController? emailAddress1221Controller;
  String? Function(BuildContext, String?)? emailAddress1221ControllerValidator;
  // State field(s) for password1221 widget.
  FocusNode? password1221FocusNode;
  TextEditingController? password1221Controller;
  late bool password1221Visibility;
  String? Function(BuildContext, String?)? password1221ControllerValidator;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    passwordVisibility = false;
    confrimVisibility = false;
    password1221Visibility = false;
  }

  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    emailAddressFocusNode?.dispose();
    emailAddressController?.dispose();

    passwordFocusNode?.dispose();
    passwordController?.dispose();

    confrimFocusNode?.dispose();
    confrimController?.dispose();

    emailAddress1221FocusNode?.dispose();
    emailAddress1221Controller?.dispose();

    password1221FocusNode?.dispose();
    password1221Controller?.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
