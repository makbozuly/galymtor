import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _icomoonFamily = 'Icomoon';

  // icomoon
  static const IconData kcopy = IconData(0xe919, fontFamily: _icomoonFamily);
  static const IconData kmessageCircleDots =
      IconData(0xe925, fontFamily: _icomoonFamily);
  static const IconData ksmartphone =
      IconData(0xe933, fontFamily: _icomoonFamily);
  static const IconData ksuitcase =
      IconData(0xe934, fontFamily: _icomoonFamily);
  static const IconData kvector = IconData(0xe935, fontFamily: _icomoonFamily);
  static const IconData k1212 = IconData(0xe91a, fontFamily: _icomoonFamily);
  static const IconData kbolt = IconData(0xe91b, fontFamily: _icomoonFamily);
  static const IconData kcalendar =
      IconData(0xe91c, fontFamily: _icomoonFamily);
  static const IconData kcamera = IconData(0xe91d, fontFamily: _icomoonFamily);
  static const IconData kcart1 = IconData(0xe91e, fontFamily: _icomoonFamily);
  static const IconData kcheckSmall =
      IconData(0xe91f, fontFamily: _icomoonFamily);
  static const IconData kchevronSmallDown =
      IconData(0xe920, fontFamily: _icomoonFamily);
  static const IconData kchevronSmallLeft =
      IconData(0xe921, fontFamily: _icomoonFamily);
  static const IconData kchevronSmallRight =
      IconData(0xe922, fontFamily: _icomoonFamily);
  static const IconData kchevronSmallUp =
      IconData(0xe923, fontFamily: _icomoonFamily);
  static const IconData kcrossSmall =
      IconData(0xe924, fontFamily: _icomoonFamily);
  static const IconData kcrown2 = IconData(0xe926, fontFamily: _icomoonFamily);
  static const IconData kdislike = IconData(0xe927, fontFamily: _icomoonFamily);
  static const IconData kedit4 = IconData(0xe928, fontFamily: _icomoonFamily);
  static const IconData kgift = IconData(0xe929, fontFamily: _icomoonFamily);
  static const IconData kgroup3 = IconData(0xe92a, fontFamily: _icomoonFamily);
  static const IconData kheart = IconData(0xe92b, fontFamily: _icomoonFamily);
  static const IconData klike = IconData(0xe92c, fontFamily: _icomoonFamily);
  static const IconData kplay = IconData(0xe92d, fontFamily: _icomoonFamily);
  static const IconData kplusSmall =
      IconData(0xe92e, fontFamily: _icomoonFamily);
  static const IconData kpower = IconData(0xe92f, fontFamily: _icomoonFamily);
  static const IconData kshare1 = IconData(0xe930, fontFamily: _icomoonFamily);
  static const IconData kwallet = IconData(0xe931, fontFamily: _icomoonFamily);
  static const IconData kwarningCircle =
      IconData(0xe932, fontFamily: _icomoonFamily);
  static const IconData kbell = IconData(0xe900, fontFamily: _icomoonFamily);
  static const IconData kbookmark =
      IconData(0xe901, fontFamily: _icomoonFamily);
  static const IconData kcam = IconData(0xe902, fontFamily: _icomoonFamily);
  static const IconData kcardiology =
      IconData(0xe903, fontFamily: _icomoonFamily);
  static const IconData kemoteSad =
      IconData(0xe904, fontFamily: _icomoonFamily);
  static const IconData kemoteSmile =
      IconData(0xe905, fontFamily: _icomoonFamily);
  static const IconData keyeClosed =
      IconData(0xe906, fontFamily: _icomoonFamily);
  static const IconData keyeOpen = IconData(0xe907, fontFamily: _icomoonFamily);
  static const IconData kfemale = IconData(0xe908, fontFamily: _icomoonFamily);
  static const IconData kgrid4 = IconData(0xe909, fontFamily: _icomoonFamily);
  static const IconData kgroup2 = IconData(0xe90a, fontFamily: _icomoonFamily);
  static const IconData klistCenter =
      IconData(0xe90b, fontFamily: _icomoonFamily);
  static const IconData klocation1 =
      IconData(0xe90c, fontFamily: _icomoonFamily);
  static const IconData klockOn = IconData(0xe90d, fontFamily: _icomoonFamily);
  static const IconData kmale = IconData(0xe90e, fontFamily: _icomoonFamily);
  static const IconData kmap = IconData(0xe90f, fontFamily: _icomoonFamily);
  static const IconData kphoneCall =
      IconData(0xe910, fontFamily: _icomoonFamily);
  static const IconData kquote = IconData(0xe911, fontFamily: _icomoonFamily);
  static const IconData ksearch = IconData(0xe912, fontFamily: _icomoonFamily);
  static const IconData ksend2 = IconData(0xe913, fontFamily: _icomoonFamily);
  static const IconData ksettings =
      IconData(0xe914, fontFamily: _icomoonFamily);
  static const IconData kshare2 = IconData(0xe915, fontFamily: _icomoonFamily);
  static const IconData kstar1 = IconData(0xe916, fontFamily: _icomoonFamily);
  static const IconData ktrash2 = IconData(0xe917, fontFamily: _icomoonFamily);
  static const IconData kuser1 = IconData(0xe918, fontFamily: _icomoonFamily);
}
