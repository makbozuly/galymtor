import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['kk', 'ru'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? kkText = '',
    String? ruText = '',
  }) =>
      [kkText, ruText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // profile
  {
    '4rx9jxwp': {
      'kk': 'Менің аккаунтым',
      'ru': 'Мой аккаунт',
    },
    'c5k9xq43': {
      'kk': 'Тіл',
      'ru': 'Язык',
    },
    '3ho8x0ur': {
      'kk': 'Сұрақ & Жауап',
      'ru': 'Вопросы и ответы',
    },
    'gfsyl61h': {
      'kk': 'Тех көмекпен байланысу',
      'ru': 'Связаться с тех поддержкой',
    },
    '6xwfbc39': {
      'kk': 'Менеджермен байланысу',
      'ru': 'Связаться с менеджером ',
    },
    'qli3glhq': {
      'kk': 'Төлемді қалпына келтіру',
      'ru': 'Восстановление платежа',
    },
    'ckd9v2vr': {
      'kk': 'Шығу',
      'ru': 'Выйти',
    },
    'xfl5yuka': {
      'kk': 'Менің аккаунтым',
      'ru': 'Мой профиль',
    },
  },
  // Home
  {
    'gsd4zvyv': {
      'kk': 'Сәлем, ',
      'ru': 'Привет,',
    },
    '3ukdds6s': {
      'kk': '',
      'ru': '',
    },
    'znwj9mus': {
      'kk': 'Курстар',
      'ru': 'КУРСЫ',
    },
    'lfcrcn6h': {
      'kk': 'Сұлулық коды',
      'ru': 'Сұлулық коды',
    },
    'p5kmvt9k': {
      'kk': 'by Гүлзира Айдарбекова',
      'ru': 'by Гульзира Айдарбекова',
    },
    'munxn6qc': {
      'kk': 'Бастау',
      'ru': 'Начать',
    },
    '96m045cq': {
      'kk': 'Басты бет',
      'ru': 'Главный',
    },
  },
  // Satyp_alu
  {
    'w6ey8hcr': {
      'kk': 'Стандарт 1',
      'ru': 'Стандарт 1',
    },
    'de47i0hz': {
      'kk': ' ',
      'ru': '',
    },
    'ftvj65kj': {
      'kk': '',
      'ru': '',
    },
    '0d9y8cls': {
      'kk': '4 модуль, 25 видео сабақ',
      'ru': '4 модуль, 12  видео урок',
    },
    '0zhy8tlu': {
      'kk': '26 000₸',
      'ru': '26 000₸',
    },
    'lhusg25s': {
      'kk': 'Стандарт 2',
      'ru': 'Стандарт 2',
    },
    'tah643k1': {
      'kk': ' ',
      'ru': '',
    },
    'cv341zoq': {
      'kk': '',
      'ru': '',
    },
    '1sj2emzk': {
      'kk': '4 модуль, 50 видео сабақ',
      'ru': '4 модуль, 50 видео урок,  чат, 4 эфир, сертификат',
    },
    'j77au54x': {
      'kk': '26 000₸',
      'ru': '26 000₸',
    },
    'wcpd9wko': {
      'kk': 'Вип',
      'ru': 'Вип',
    },
    'xk7ts0kd': {
      'kk': ' ',
      'ru': '',
    },
    'lc0xo7bl': {
      'kk': '',
      'ru': '',
    },
    'aq7pfrtz': {
      'kk': '4 модуль, 50 видео сабақ',
      'ru': '4 модуль, 50 видео урок,  чат, 4 эфир, сертификат, консультация',
    },
    '6ati53cp': {
      'kk': '50 000₸',
      'ru': '50 000₸',
    },
    'xf7w5uv6': {
      'kk': 'Сұрақ & Жауап',
      'ru': 'Вопросы и ответы',
    },
    's922pnfq': {
      'kk': 'Пакеттер',
      'ru': 'Пакеты',
    },
    'n37piwn7': {
      'kk': 'Абонемент',
      'ru': '',
    },
  },
  // Suraq_zhauap
  {
    '062se8rm': {
      'kk': 'Сұрақ-жауап',
      'ru': 'Вопрос и ответ',
    },
    'kzlz5nxw': {
      'kk': 'Абонемент',
      'ru': '',
    },
  },
  // current_glav_news
  {
    '5is4b7hv': {
      'kk': 'Жаңалық',
      'ru': 'Новости',
    },
    '3kuf1ql7': {
      'kk': 'Новости',
      'ru': '',
    },
  },
  // current_module_lessons
  {
    'zs8ouv79': {
      'kk': 'сабақ',
      'ru': 'урок',
    },
    '6lyvuodk': {
      'kk': 'Модуль сабақтары',
      'ru': 'Модульные уроки',
    },
    '0sr0sfw8': {
      'kk': 'Уроки',
      'ru': '',
    },
  },
  // Xabarlamalar
  {
    'iyo2oni0': {
      'kk': 'Ескертпе',
      'ru': 'Уведомление',
    },
    '335z6436': {
      'kk': 'Абонемент',
      'ru': '',
    },
  },
  // edit_profile
  {
    'k2l0keu7': {
      'kk': 'Аты',
      'ru': 'Имя',
    },
    'fnldc7jn': {
      'kk': '',
      'ru': '',
    },
    'arqhz6t8': {
      'kk': 'Телефон нөмір',
      'ru': 'Телефон номер',
    },
    'rfgp67hc': {
      'kk': '',
      'ru': '',
    },
    'g9fuhnyx': {
      'kk': 'Аккаунтты жою',
      'ru': 'Удалить аккаунт',
    },
    '3iwsl9r8': {
      'kk': 'Сақтау',
      'ru': 'Сохранить',
    },
    '59xi1smr': {
      'kk': 'Өзгерту',
      'ru': 'Редактировать',
    },
    'lmas4rlk': {
      'kk': 'Мой аккаунт',
      'ru': '',
    },
  },
  // current_lesson
  {
    'dsp3eklf': {
      'kk': 'Материялды жүктеу',
      'ru': 'Скачать материал',
    },
    'o5o89rmq': {
      'kk': 'Келесі',
      'ru': 'Следующий',
    },
    'r4o3rsdg': {
      'kk': 'Сабақ',
      'ru': 'Урок',
    },
    'pcnpuu0c': {
      'kk': 'Абонемент',
      'ru': '',
    },
  },
  // Addnews
  {
    'tdalxmq1': {
      'kk': 'Аты',
      'ru': 'Название',
    },
    'hk4iivtx': {
      'kk': 'Аты',
      'ru': 'Название',
    },
    'c1nl6sf1': {
      'kk': 'Сипаттамасы',
      'ru': 'Описание',
    },
    'd5y0bhgb': {
      'kk': 'Реттік номері',
      'ru': 'Серийный номер',
    },
    'jwc5btl5': {
      'kk': 'Жіберу',
      'ru': 'Отправить',
    },
    'qjn0jo9f': {
      'kk': 'Жаңалық қосу',
      'ru': 'Добавить новость',
    },
    'hrcpxmc8': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // admin_add_course
  {
    '8e32hfhg': {
      'kk': 'Аты',
      'ru': 'Название',
    },
    'qydc4wz1': {
      'kk': 'Сипаттамасы',
      'ru': 'Описание',
    },
    '04fvd6jg': {
      'kk': 'ID (реті)',
      'ru': 'ID (порядок)',
    },
    'cgw2x5nb': {
      'kk': 'kk',
      'ru': 'kk',
    },
    'ew0qmlai': {
      'kk': 'ru',
      'ru': 'ru',
    },
    'reotnmpm': {
      'kk': 'Тілді таңдау',
      'ru': 'Выберите язык',
    },
    'x5lw9hcx': {
      'kk': 'Search for an item...',
      'ru': '',
    },
    'kgkhfa0y': {
      'kk': 'Жариялау',
      'ru': 'Опубликовать',
    },
    'ar2qq3md': {
      'kk': 'Курс қосу',
      'ru': 'Добавить курс',
    },
    'lk7gznen': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // admin_add_lesson
  {
    'lxhq187b': {
      'kk': 'Атауы',
      'ru': 'Название',
    },
    'q4yarxyb': {
      'kk': 'Сипаттамасы',
      'ru': 'Описание',
    },
    '97psjics': {
      'kk': 'Баннер сілтемесі',
      'ru': 'Ссылка баннера',
    },
    'c0rdj99b': {
      'kk': 'Video url',
      'ru': '',
    },
    'w7c5wehh': {
      'kk': 'ID (реті)',
      'ru': 'ID (порядок)',
    },
    'cwp1hogt': {
      'kk': 'Shabyt',
      'ru': 'Shabyt',
    },
    '0ydus4wu': {
      'kk': 'Қосу',
      'ru': 'Добавить',
    },
    '59z1gibs': {
      'kk': 'Сабақ қосу',
      'ru': 'Добавить урок',
    },
    'cy74gty8': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // addnotif
  {
    'yqz6lo71': {
      'kk': 'Название',
      'ru': '',
    },
    'boznxxgs': {
      'kk': 'Описание',
      'ru': '',
    },
    't521pcsa': {
      'kk': 'Отправить',
      'ru': '',
    },
    '1bg7n4eu': {
      'kk': 'Ескертпе қосу',
      'ru': 'Добавить заметку',
    },
    'v09xy0s8': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // addblock
  {
    'u7htawpl': {
      'kk': 'Название',
      'ru': '',
    },
    'rnr214nc': {
      'kk': 'Описание',
      'ru': '',
    },
    'ig0f21jh': {
      'kk': 'Отправить',
      'ru': '',
    },
    'g1if3i7w': {
      'kk': 'Контент қосу',
      'ru': 'Добавить контент',
    },
    '10b39qj0': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // admin_lessons
  {
    '0843837w': {
      'kk': 'Сабақ қосу',
      'ru': 'Добавить урок',
    },
    'ylxsd17m': {
      'kk': 'Сабақтар',
      'ru': 'Уроки',
    },
    '4335lcan': {
      'kk': 'Уроки',
      'ru': '',
    },
  },
  // admin
  {
    'znjekknw': {
      'kk': 'Қосу st',
      'ru': 'Добавить 1st',
    },
    'buxz4aga': {
      'kk': 'Для женшина',
      'ru': '',
    },
    'zlrvgx97': {
      'kk': 'Для женшина которое узнат причина',
      'ru': '',
    },
    'z47acj03': {
      'kk': 'Смотреть',
      'ru': '',
    },
    'ir8f8m08': {
      'kk': 'Курс таңдаңыз',
      'ru': 'Выберите курс',
    },
    'fmhav9bz': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // Authentication
  {
    'uqsyfz7y': {
      'kk': 'Тіркелу',
      'ru': 'Регистрация',
    },
    'amuwp5he': {
      'kk': 'Аккаунт тіркеу',
      'ru': 'Создать аккаунт',
    },
    'lx249l4q': {
      'kk':
          'Егер сіз бұрын курс алған болсаңыз \nменеджермен байланысыңыз, не\nменеджер сізге доступ береді',
      'ru':
          'Если вы ранее купили курс, то администратор предоставит доступ к созданному аккаунту',
    },
    '0j3veh41': {
      'kk': 'Почта',
      'ru': 'Почта',
    },
    'yct7vt1b': {
      'kk': 'Құпия сөз',
      'ru': 'Пароль',
    },
    'cetss6to': {
      'kk': 'Құпия сөзді қайталаңыз',
      'ru': 'Подвердите пароль',
    },
    '2s5ijvaf': {
      'kk': 'Тіркелу',
      'ru': 'Регистрировать',
    },
    'yibj7s8t': {
      'kk': 'Кіру',
      'ru': 'Вход',
    },
    'vwchcsis': {
      'kk': 'Қош келдіңіз !',
      'ru': 'Добро пожаловать!',
    },
    '4upqiv75': {
      'kk': 'Егер тіркелген болсаңыз, аккаунтқа кіріңіз',
      'ru': 'Войдите в аккаунт, если вы зарегистрированы',
    },
    'yx6iyc05': {
      'kk': 'Почта',
      'ru': 'Почта',
    },
    'fte0hnnw': {
      'kk': 'Құпия сөз',
      'ru': 'Пароль',
    },
    'qfeq63z0': {
      'kk': 'Кіру',
      'ru': 'Войти',
    },
    'q85kvb0d': {
      'kk': 'Құпия сөзді ұмыттыңыз ба?',
      'ru': 'Забыли пароль?',
    },
    '43e5fp61': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // admin_main_panel
  {
    'e2w0t98v': {
      'kk': 'Жаңалықтар',
      'ru': 'Новости',
    },
    '5gdkwj6b': {
      'kk': 'Қосу',
      'ru': 'Добавить',
    },
    'psvv2cxf': {
      'kk': 'Курстар',
      'ru': 'Курсы',
    },
    'cn29m8hx': {
      'kk': 'Қосу',
      'ru': 'Добавить',
    },
    'ip40rofq': {
      'kk': 'Блок ',
      'ru': 'Блок',
    },
    'ewijdrx1': {
      'kk': 'Қосу',
      'ru': 'Добавить',
    },
    'wg8jd70a': {
      'kk': 'Сабақтар',
      'ru': 'Уроки',
    },
    'bs61rlu2': {
      'kk': 'Қосу',
      'ru': 'Добавить',
    },
    '0wyrvxak': {
      'kk': 'Студенттер',
      'ru': 'Студенты',
    },
    'q3qzgvg2': {
      'kk': 'Өңдеу',
      'ru': 'Редактировать',
    },
    'ktifida8': {
      'kk': 'Админ панель',
      'ru': 'Панель администратора',
    },
    'uvged16g': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // Addstudent
  {
    'sceopy5g': {
      'kk': 'Аты',
      'ru': 'Имя',
    },
    'bzyqg8p6': {
      'kk': 'Почта',
      'ru': 'Почта',
    },
    'uey089xh': {
      'kk': 'Пароль',
      'ru': 'Пароль',
    },
    'a67vxoi4': {
      'kk': 'Shabyt',
      'ru': 'Shabyt',
    },
    'q3ii2eo5': {
      'kk': 'Доступты таңдаңыз',
      'ru': 'Выберите Доступ',
    },
    '6geh8snc': {
      'kk': 'Search for an item...',
      'ru': '',
    },
    '0wzdtllf': {
      'kk': 'Қосу',
      'ru': 'Создать',
    },
    'rruhyc6n': {
      'kk': 'Студент қосу',
      'ru': 'Добавить студента',
    },
    'nkq3bbam': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // add_q_a
  {
    'dlvy4h8d': {
      'kk': '',
      'ru': '',
    },
    'ayrgws5c': {
      'kk': 'Сұрақ',
      'ru': 'Вопрос',
    },
    'qguwjnpz': {
      'kk': 'Жауап',
      'ru': 'Ответ',
    },
    'yfzditu2': {
      'kk': 'ID (реті)',
      'ru': 'ID (порядок)',
    },
    '7e7bravl': {
      'kk': 'Жіберу',
      'ru': 'Отправить',
    },
    '08wy9oqv': {
      'kk': 'Сұрақ жауап қосу',
      'ru': 'Добавить вопрос и ответ',
    },
    'ty1bxdk7': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // edit_course
  {
    'qcomqsek': {
      'kk': 'Өңдеу',
      'ru': 'Редактировать',
    },
    'plk4qo2r': {
      'kk': 'Для женшина',
      'ru': '',
    },
    'wsiryi28': {
      'kk': 'Для женшина которое узнат причина',
      'ru': '',
    },
    'n3ojsiw8': {
      'kk': 'Смотреть',
      'ru': '',
    },
    'rraqq6s4': {
      'kk': 'Курсты таңдаңыз',
      'ru': 'Выберите курс',
    },
    'j90q3igf': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // editUser
  {
    '8wp7nddh': {
      'kk': 'Сұлулық коды Стандарт 1 ',
      'ru': 'Бьюти-код Стандарт 1',
    },
    'v3d00bzz': {
      'kk': 'Өзгерту',
      'ru': 'Изменить',
    },
    'eak6het1': {
      'kk': 'Сұлулық коды Стандарт 2',
      'ru': 'Бьюти-код Стандарт  2',
    },
    'w9fka3ow': {
      'kk': 'Өзгерту',
      'ru': 'Изменить',
    },
    'r87viy27': {
      'kk': 'Сұлулық коды Вип 3',
      'ru': 'Бьюти-код Вип 3',
    },
    'zkv3lsgq': {
      'kk': 'Өзгерту',
      'ru': 'Изменить',
    },
    'ecjs0c9v': {
      'kk': 'Кірді',
      'ru': 'Вошел',
    },
    '9q7jwg79': {
      'kk': 'Студент',
      'ru': 'Студент',
    },
    '0u4rhsjp': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // forgot_password
  {
    '13aq54mv': {
      'kk': 'Электронды почтаңызға \nсілтеме жібереміз!',
      'ru': 'Мы отправим ссылку на вашу электронную почту,',
    },
    'miasz0xq': {
      'kk':
          'Cол сілтеме арқылы құпия сөзді қалпына келтіреcіз. Төменге эл. почтаңызды жазып жіберіңіз!',
      'ru':
          'Мы вышлем вам электронное письмо со ссылкой для сброса вашего пароля, пожалуйста, введите ниже адрес электронной почты, связанный с вашей учетной записью.',
    },
    'kasbueo3': {
      'kk': 'Почтаңызды жазыңыз...',
      'ru': 'Напишите почту...',
    },
    'z0seiri3': {
      'kk': 'Жіберу',
      'ru': 'Отправить',
    },
    'jtorar1u': {
      'kk': 'Қалпына келтіру',
      'ru': 'Восстановление',
    },
    'kvwfifd2': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // kaspitutorial
  {
    'bqkb9sxs': {
      'kk':
          'ТӨЛЕУ НҰСҚАУЛАРЫ:\n\n1. Төлем бетінен Shabyt пакетін таңдаңыз\n2. Kaspi қосымшасына өтіп, аккаунты арқылы таңдаған курстың бағасын енгізіңіз\n3. Төлегеннен кейін менеджерге чек жіберіңіз\n4. Менеджер төлеміңізді тексереді\n5. Менеджер сізге доступ ашылғанын хабарлайды',
      'ru':
          'ИНСТРУКЦИЯ ПО ОПЛАТЕ:\n\n1. Выберите пакет «Shabyt» на странице оформления заказа.\n2. Зайдите в приложение Kaspi и введите стоимость выбранного курса через свой аккаунт.\n3. После оплаты отправьте чек менеджеру.\n4. Менеджер проверит вашу оплату.\n5. Менеджер сообщит вам, что доступ открыт.',
    },
    'gq7c09cu': {
      'kk': 'Kaspi арқылы төлеу',
      'ru': 'Оплатить через Kaspi',
    },
    'bvo8mts9': {
      'kk': 'Төлем жасағаннан кейін',
      'ru': 'После оплата',
    },
    'fcun5492': {
      'kk': 'Чек жіберу',
      'ru': 'Отправить чек ',
    },
    'cv7acixp': {
      'kk': 'Kaspi.kz нұсқаулық',
      'ru': 'Kaspi.kz инструкция',
    },
    'ikeluoed': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // module_of_course
  {
    'c7rv21x9': {
      'kk':
          'Бұл курсты соңына дейін өту арқылы, отбасыңыздың 5 бағыттағы проблемаларын шешу жолдарын білесіз.',
      'ru': 'Пройдя этот курс, вы научитесь решать 5 проблем в вашей семье.',
    },
    '9q1p4u4z': {
      'kk': 'Курсты соңына дейін  өту арқылы нәтижиеге жете аласыз.',
      'ru': 'Добиться результата можно, пройдя курс до конца.',
    },
    'ry95updl': {
      'kk': 'Сабақ модульдері',
      'ru': 'Модули курса',
    },
    'q8x9cr4k': {
      'kk': 'Сұлулық коды',
      'ru': 'Сұлулық коды',
    },
    'li2g1jg6': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // welcompage
  {
    'kmpe5xsi': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // contents
  {
    'aetohs90': {
      'kk': 'Жаңалықтар',
      'ru': 'Новости',
    },
    'rjy1z0ot': {
      'kk': 'Контент',
      'ru': 'Контент',
    },
  },
  // currentcontent
  {
    '9km0hvdc': {
      'kk': 'Жаңалықтар',
      'ru': 'Новости',
    },
    'eam0wjej': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // users
  {
    '2m03y2ol': {
      'kk': 'Студентті іздеу',
      'ru': 'Поиск студента',
    },
    '94uhibf4': {
      'kk': 'Option 1',
      'ru': '',
    },
    '0bbnidoi': {
      'kk': 'Қолданушылар',
      'ru': 'Пользователи',
    },
    '1gdczs99': {
      'kk': 'Home',
      'ru': '',
    },
  },
  // PhotoUpload
  {
    'gce013sn': {
      'kk': 'Қане, танысайық',
      'ru': 'Давай, познакомимся ',
    },
    'myjqxnog': {
      'kk': 'Профиль суретін жүкте',
      'ru': 'Загрузите изображение своего профиля',
    },
    'xe5zh9oi': {
      'kk': 'Аты-жөн',
      'ru': 'Введите Ваши имя и фамилию',
    },
    'w0u34v7h': {
      'kk': 'Телефон номер',
      'ru': 'Ваш номер телефон',
    },
    'e4cphbhr': {
      'kk': 'Достар арқылы',
      'ru': 'Через друзей',
    },
    'hlm3iqpu': {
      'kk': 'Соц. сеть',
      'ru': 'Соц. сеть',
    },
    'e2bb7spv': {
      'kk': 'Рекламадан',
      'ru': 'Из реклама',
    },
    'avbqn0c8': {
      'kk': 'Басқа',
      'ru': 'Другое',
    },
    'fqikenme': {
      'kk': 'Біз жайлы қайдан естідіңіз?',
      'ru': 'Как вы узнали о нас?',
    },
    'meqdsbe6': {
      'kk': 'Search for an item...',
      'ru': '',
    },
    '762n96qh': {
      'kk': 'Сақтау',
      'ru': 'Сохранить',
    },
  },
  // pay_for_premium
  {
    'g2jqmepz': {
      'kk': 'Төлем туралы ақпарат',
      'ru': 'Информация об оплате',
    },
    'fg75tjk0': {
      'kk': 'Курс атауы:',
      'ru': 'Название курса:',
    },
    'ubdtkejc': {
      'kk': 'Сұлулық коды',
      'ru': 'Код красоты',
    },
    'pinopl44': {
      'kk': 'Курс ұзақтығы:',
      'ru': 'Длительность курса:',
    },
    'e0vdjyxr': {
      'kk': '6 ай',
      'ru': '6 месяцев',
    },
    'f87ouyl3': {
      'kk': 'Курс бағасы:',
      'ru': 'Стоимость курса:',
    },
    'r7wj5oo1': {
      'kk': '26 000',
      'ru': '26 000',
    },
    '5eh7ftur': {
      'kk': 'Қосымша ақпарат:',
      'ru': 'Дополнительная информация:',
    },
    'ypqroff6': {
      'kk': '- pdf материял',
      'ru': '- pdf материял',
    },
    'ygbb0urx': {
      'kk': 'Terms of Use',
      'ru': 'Terms of Use',
    },
    '7qcat318': {
      'kk': 'Privacy Policy',
      'ru': 'Privacy Policy',
    },
    '0h6bcucj': {
      'kk': 'Төлеу',
      'ru': 'Оплатить',
    },
    'vz48eqq0': {
      'kk': 'Kaspi арқылы төлеу',
      'ru': 'Оплата через Каспи',
    },
  },
  // youblocked
  {
    'kzlo0szr': {
      'kk': 'Сіз блокқа кетесіз !',
      'ru': 'Вы будете заблокирован !',
    },
    'c5iytvsu': {
      'kk':
          'Бірнеше құрылғымен жүйеге кіре және пайдалана алмайсыз! Егер бұл сіз болсаңыз, менеджерге жазыңыз',
      'ru':
          'Вы не сможете войти с несколькими устройствами! Если это вы напишите менеджеру',
    },
    'kdvvomxb': {
      'kk': 'Кері',
      'ru': 'Отмена',
    },
    'xi7iw4g8': {
      'kk': 'Жазу',
      'ru': 'Написать',
    },
  },
  // areyou_sure_to_leave
  {
    '2afxfle7': {
      'kk': 'Ескерту !',
      'ru': 'Внимание !',
    },
    '1f07ri3u': {
      'kk':
          'Егер сіз аккаунттан шығар болсаңыз, бұл аккаунт одан кейін қолжетімсіз болады!',
      'ru':
          'После выйти из аккаунта вы не сможете занова использовать текущий аккаунт!',
    },
    'zt1ec4we': {
      'kk': 'Кері',
      'ru': 'Отмена',
    },
    '3socugto': {
      'kk': 'Шығу',
      'ru': 'Выйти',
    },
  },
  // success_payment
  {
    'j5cwuac8': {
      'kk': 'Сәтті төлем !',
      'ru': 'Успешный оплата !',
    },
    '4g40kgpl': {
      'kk':
          'Сіз сәтті төлем жасадыңыз. Сізге доступ ашық. Негізгі бетке өтіп, курсты ашсаңыз болады',
      'ru':
          'Вы успешно оплатили. Теперь вам открыто доступ. Перейдите в главный меню и откройте свой курс',
    },
    'o29i9k88': {
      'kk': 'Негізгі бет',
      'ru': 'Главный экран',
    },
  },
  // unsuccess_payment
  {
    '6940qz46': {
      'kk': 'Сәтсіз төлем !',
      'ru': 'Неуспешный оплата !',
    },
    'im961j2u': {
      'kk': 'Төлем алынбады. Доступқа ие болу үшін төлемді қайталап көріңіз',
      'ru':
          'Что то пошло не так. Попробуйте снова оплатить что бы получить доступ',
    },
    'ekhxz15h': {
      'kk': 'Негізгі бет',
      'ru': 'Главный экран',
    },
  },
  // surakandjauap
  {
    '4b2sr7bt': {
      'kk': 'Lorem ipsum dolor sit amet, consectetur adipiscing...',
      'ru': '',
    },
  },
  // pay_for_standard
  {
    'enz3h00c': {
      'kk': 'Төлем туралы ақпарат',
      'ru': 'Информация об оплате',
    },
    'vhyaea18': {
      'kk': 'Курс атауы:',
      'ru': 'Название курса:',
    },
    'yw77tl66': {
      'kk': 'Сұлулық коды',
      'ru': 'Код красоты',
    },
    'l8xpe19n': {
      'kk': 'Курс ұзақтығы:',
      'ru': 'Длительность курса:',
    },
    'vgpce0y8': {
      'kk': '6 ай',
      'ru': '6 месяцев',
    },
    'cvhzt241': {
      'kk': 'Курс бағасы:',
      'ru': 'Стоимость курса:',
    },
    'en9tilxu': {
      'kk': '26 000',
      'ru': '26 000',
    },
    'g3y18hbz': {
      'kk': 'Қосымша ақпарат:',
      'ru': 'Дополнительная информация:',
    },
    'nlazfe16': {
      'kk': '- pdf материял',
      'ru': '- pdf материял',
    },
    '7wkear13': {
      'kk': 'Terms of Use',
      'ru': 'Terms of Use',
    },
    'xvi8k8zq': {
      'kk': 'Privacy Policy',
      'ru': 'Privacy Policy',
    },
    '8wmrs423': {
      'kk': 'Төлеу',
      'ru': 'Оплатить',
    },
    'gq175pgf': {
      'kk': 'Kaspi арқылы төлеу',
      'ru': 'Оплата через Каспи',
    },
  },
  // pay_for_vip
  {
    'php8ss95': {
      'kk': 'Төлем туралы ақпарат',
      'ru': 'Информация об оплате',
    },
    '0hy7wfpu': {
      'kk': 'Курс атауы:',
      'ru': 'Название курса:',
    },
    '6hfe93zp': {
      'kk': 'Сұлулық коды',
      'ru': 'Код красоты',
    },
    'ua52ssqa': {
      'kk': 'Курс ұзақтығы:',
      'ru': 'Длительность курса:',
    },
    '4ixz4y4f': {
      'kk': '6 ай',
      'ru': '6 месяцев',
    },
    '1hop6xqt': {
      'kk': 'Курс бағасы:',
      'ru': 'Стоимость курса:',
    },
    'pinuf3v5': {
      'kk': '50 000',
      'ru': '50 000',
    },
    'vdi36jgk': {
      'kk': 'Қосымша ақпарат:',
      'ru': 'Дополнительная информация:',
    },
    'd4v9e3c5': {
      'kk': '- pdf материял',
      'ru': '- pdf материял',
    },
    'wyx7p8xi': {
      'kk': 'Terms of Use',
      'ru': 'Terms of Use',
    },
    '828rtbwy': {
      'kk': 'Privacy Policy',
      'ru': 'Privacy Policy',
    },
    '3cmka6fi': {
      'kk': 'Төлеу',
      'ru': 'Оплатить',
    },
    '00c9c2tk': {
      'kk': 'Kaspi арқылы төлеу',
      'ru': 'Оплата через Каспи',
    },
  },
  // Miscellaneous
  {
    'lag3qhh2': {
      'kk': 'Профильге сурет қою үшін осы мүмкіндікке рұқсат беріңіз',
      'ru': 'Разрешите эту функцию для вставки изображения в профиль',
    },
    '28h9fek2': {
      'kk': 'Профильге фотосуретті жүктеу үшін осы мүмкіндікке рұқсат беріңіз',
      'ru': 'Разрешить эту функцию для загрузки фотографии в профиль',
    },
    'wrgygz4g': {
      'kk':
          'Сізге соңғы жаңалықтар жайлы хабарлау үшін бізге осы мүмкіндікке рұқсат беріңіз',
      'ru':
          'Пожалуйста, дайте нам доступ к этой функции, чтобы сообщить вам о последних новостях',
    },
    'ru3cdfxn': {
      'kk': '',
      'ru': '',
    },
    '9bjgkaau': {
      'kk': '',
      'ru': '',
    },
    'cblktgqh': {
      'kk': '',
      'ru': '',
    },
    'caeynlqm': {
      'kk': '',
      'ru': '',
    },
    '53uwrrd9': {
      'kk': '',
      'ru': '',
    },
    '9ci1noa6': {
      'kk': '',
      'ru': '',
    },
    'm4lkgdet': {
      'kk': '',
      'ru': '',
    },
    'fna6xlsy': {
      'kk': '',
      'ru': '',
    },
    'lf7mrxz0': {
      'kk': '',
      'ru': '',
    },
    'sobmlejd': {
      'kk': '',
      'ru': '',
    },
    'x5w4bmea': {
      'kk': '',
      'ru': '',
    },
    'sggo8qrk': {
      'kk': '',
      'ru': '',
    },
    '28wwotgp': {
      'kk': '',
      'ru': '',
    },
    '45qi7chj': {
      'kk': '',
      'ru': '',
    },
    'w3we7w9h': {
      'kk': '',
      'ru': '',
    },
    'g50m88cr': {
      'kk': '',
      'ru': '',
    },
    'dv1ydggh': {
      'kk': '',
      'ru': '',
    },
    '3360guza': {
      'kk': '',
      'ru': '',
    },
    '6gsvb47i': {
      'kk': '',
      'ru': '',
    },
    'hla0br9z': {
      'kk': '',
      'ru': '',
    },
    '39q4ev60': {
      'kk': '',
      'ru': '',
    },
    'afb8oeag': {
      'kk': '',
      'ru': '',
    },
    '7fbawoi0': {
      'kk': '',
      'ru': '',
    },
  },
].reduce((a, b) => a..addAll(b));
